//
//  LocationBubbleChatView.h
//  Messenger
//
//  Created by muqiao.hyk on 13-4-19.
//
//

#import "YWBaseBubbleChatView.h"

@interface WXOLocationBubbleChatView : YWBaseBubbleChatView

@end
