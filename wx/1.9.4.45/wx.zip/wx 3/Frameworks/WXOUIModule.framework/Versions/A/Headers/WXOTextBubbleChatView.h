//
//  WXOTextBubbleChatView.h
//  Messenger
//
//  Created by muqiao.hyk on 13-4-19.
//
//

#import <Foundation/Foundation.h>

#import "YWBaseBubbleChatView.h"

@interface WXOTextBubbleChatView : YWBaseBubbleChatView<YWBaseBubbleChatViewInf>
@end
