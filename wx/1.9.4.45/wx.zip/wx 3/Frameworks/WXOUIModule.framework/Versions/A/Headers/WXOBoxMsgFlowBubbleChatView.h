//
//  BoxMsgFlowBubbleChatView.h
//  WQClient
//
//  Created by qinghua.liqh on 14-3-7.
//  Copyright (c) 2014年 Alibaba. All rights reserved.
//

#import "YWBaseBubbleChatView.h"

@interface WXOBoxMsgFlowBubbleChatView : YWBaseBubbleChatView
@end
