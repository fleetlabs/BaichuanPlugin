//
//  WXOWebBubbleView.h
//  Messenger
//
//  Created by 慕桥(黄玉坤) on 13-11-6.
//
//

#import "YWBaseBubbleChatView.h"

@interface WXOWebBubbleView : YWBaseBubbleChatView
@end
