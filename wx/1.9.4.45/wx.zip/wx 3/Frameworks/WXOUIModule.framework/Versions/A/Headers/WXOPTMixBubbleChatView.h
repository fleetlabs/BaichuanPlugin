//
//  WXOPTMixBubbleChatView.h
//  Messenger
//
//  Created by muqiao.hyk on 13-4-22.
//
//

#import "YWBaseBubbleChatView.h"

@interface WXOPTMixBubbleChatView : YWBaseBubbleChatView<YWBaseBubbleChatViewInf>
@property (nonatomic, strong) UIView *contentView;
@end
