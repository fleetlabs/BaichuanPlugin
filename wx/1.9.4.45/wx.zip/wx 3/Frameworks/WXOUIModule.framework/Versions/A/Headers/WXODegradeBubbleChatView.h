//
//  WXODegreeBubbleChatView.h
//  Messenger
//
//  Created by 慕桥(黄玉坤) on 12/8/14.
//
//

#import "YWBaseBubbleChatView.h"

@interface WXODegradeBubbleChatView : YWBaseBubbleChatView

@end
