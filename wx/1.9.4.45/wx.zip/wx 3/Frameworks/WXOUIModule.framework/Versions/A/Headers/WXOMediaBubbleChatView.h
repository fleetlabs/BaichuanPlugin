//
//  WXOMediaBubbleChatView.h
//  Messenger
//
//  Created by AKKun on 13-8-8.
//
//

#import "YWBaseBubbleChatView.h"

@interface WXOMediaBubbleChatView : YWBaseBubbleChatView
@end
