//
//  MultiTextBubbleView.h
//  Messenger
//
//  Created by 慕桥(黄玉坤) on 1/21/15.
//
//

#import "YWBaseBubbleChatView.h"

@interface WXOMultiTextBubbleView : YWBaseBubbleChatView
@end
