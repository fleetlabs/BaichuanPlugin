//
//  YWContactListControllerForAlphabetic.h
//  WXOpenIMUIKit
//
//  Created by huanglei on 15/7/24.
//  Copyright (c) 2015年 www.alibaba.com. All rights reserved.
//

#import "YWBaseContactListController.h"

@interface YWContactListControllerForAlphabetic : YWBaseContactListController

- (id)initWithIMKit:(YWIMKit *)aIMKit;

@end
